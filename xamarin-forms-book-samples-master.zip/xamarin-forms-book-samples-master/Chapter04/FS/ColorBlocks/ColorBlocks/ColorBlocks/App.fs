namespace ColorBlocks

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = ColorBlocksPage())

