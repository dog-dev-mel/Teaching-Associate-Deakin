namespace VerticalOptionsDemo

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = VerticalOptionsDemoPage())

