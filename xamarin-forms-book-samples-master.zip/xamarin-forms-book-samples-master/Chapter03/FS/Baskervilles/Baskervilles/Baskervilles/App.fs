namespace Baskervilles

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = BaskervillesPage())

