namespace NamedFontSizes

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = NamedFontSizesPage())

