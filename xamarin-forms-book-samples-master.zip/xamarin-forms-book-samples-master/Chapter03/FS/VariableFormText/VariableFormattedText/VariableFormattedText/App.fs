namespace VariableFormattedText

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = VariableFormattedTextPage())

