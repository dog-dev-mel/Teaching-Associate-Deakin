﻿using System;

namespace TodoREST
{
	public interface ITextToSpeech
	{
		void Speak (string text);
	}
}
